package sample;

import javafx.scene.control.Slider;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class JumpTime {
    Slider timeSlider;
    MediaPlayer mediaPlayer;
    JumpTime(Slider timeSlider, MediaPlayer mediaPlayer){
        this.mediaPlayer=mediaPlayer;
        this.timeSlider=timeSlider;
    }
    public void setMinValue(double value){
        timeSlider.setMin(value);
    }
    public void setMaxValue(double value){
        timeSlider.setMax(value);
    }
    public void setTimeSliderValue(double value){
        timeSlider.setValue(value);
    }
    public void setMediaPlayer(MediaPlayer mediaPlayer){
        this.mediaPlayer=mediaPlayer;
    }
    public void addListener(){
        timeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (timeSlider.isPressed()) {
                double val = timeSlider.getValue();
                mediaPlayer.seek(new Duration(val * 60 * 1000));
            }
        });
    }
}
