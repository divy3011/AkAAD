package sample;

import javafx.scene.control.Slider;
import javafx.scene.media.MediaPlayer;

public class Volume {
    public MediaPlayer mediaPlayer;
    public Slider volumeSlider;
    Volume(MediaPlayer mp, Slider vS){
        this.mediaPlayer = mp;
        this.volumeSlider = vS;
    }
    public void vol(){
        if(mediaPlayer.getVolume()==0){
            volumeSlider.setValue(100);
        }
        else {
            volumeSlider.setValue(mediaPlayer.getVolume()*0);
        }
    }
}
