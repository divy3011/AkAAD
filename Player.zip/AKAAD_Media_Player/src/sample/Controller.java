package sample;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;
import javafx.util.Duration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    @FXML
    private Button play;
    @FXML
    private Button replay;
    @FXML
    private Button stop;
    @FXML
    private Button slow;
    @FXML
    private Button fast;
    @FXML
    private Button exit;
    @FXML
    private Button info;
    @FXML
    private Button vol;
    @FXML
    private Slider volumeSlider;
    @FXML
    private Slider timeSlider;
    @FXML
    private Label timeComplete;
    @FXML
    private Label timeTotal;
    @FXML
    private MediaView mediaView;
    private MediaPlayer mediaPlayer;
    private String filepath;
    File file;
    Media m;
    PlayPause PP;
    Stop St;
    Info In;
    Replay Rp;
    Speed Spd;
    Vol Vl;
    Exit Ex;
    @FXML
    public void handleButtonAction(ActionEvent event){
        try {
            FileChooser chooser = new FileChooser();
            file = chooser.showOpenDialog(null);
            m = new Media(file.toURI().toURL().toString());
            if (mediaPlayer != null) {
                mediaPlayer.dispose();
            }
            mediaPlayer = new MediaPlayer(m);
            mediaView.setMediaPlayer(mediaPlayer);
            DoubleProperty width = mediaView.fitWidthProperty();
            DoubleProperty height = mediaView.fitHeightProperty();
            width.bind(Bindings.selectDouble(mediaView.sceneProperty(),"width"));
            height.bind(Bindings.selectDouble(mediaView.sceneProperty(),"height"));
            PP = new PlayPause(play,mediaPlayer);
            Spd = new Speed(mediaPlayer);
            mediaPlayer.setOnReady(() -> {
                timeSlider.setMin(0);
                timeSlider.setMax(mediaPlayer.getMedia().getDuration().toMinutes());
                timeSlider.setValue(0);
            });
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
            mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                Duration d = mediaPlayer.getCurrentTime();
                timeSlider.setValue(d.toMinutes());
            });
            timeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
                if (timeSlider.isPressed()) {
                    double val = timeSlider.getValue();
                    mediaPlayer.seek(new Duration(val * 60 * 1000));
                }
            });
            volumeSlider.setValue(mediaPlayer.getVolume()*100);
            volumeSlider.valueProperty().addListener(observable -> {
                mediaPlayer.setVolume(volumeSlider.getValue()/100);
                if(volumeSlider.getValue()==0){
                    try {
                        vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/mute.png"))));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    try {
                        vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/volume.png"))));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

            });
            mediaPlayer.currentTimeProperty().addListener(observable -> {
                Duration tC = mediaPlayer.getCurrentTime();
                Duration tT = mediaPlayer.getTotalDuration();
                String C= FormatTime.formatTime(tC,tC);
                int index_C=C.indexOf('/');
                String TC=C.substring(0,index_C);
                String T= FormatTime.formatTime(tT,tT);
                int index_T=T.indexOf('/');
                String TT=T.substring(0,index_T);
                timeComplete.setText(TC);
                timeTotal.setText(TT);
            });

            mediaPlayer.play();
            try {
                play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/pause.png"))));
                vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/volume.png"))));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void info(ActionEvent event) {
        In = new Info(file,m);
        In.info();
    }
    @FXML
    public void playpause(ActionEvent event){
        MediaPlayer.Status status = mediaPlayer.getStatus();
        if(status==MediaPlayer.Status.PAUSED||status==MediaPlayer.Status.HALTED||status==MediaPlayer.Status.STOPPED){
            PP.play();
        }
        else{
            PP.pause();
        }
    }
    @FXML
    public void stop(ActionEvent event){
        St = new Stop(stop,play,mediaPlayer);
        St.stop();
    }
    @FXML
    public void fast(ActionEvent event){
        Spd.fast();
    }
    @FXML
    public void slow(ActionEvent event){
        Spd.slow();
    }
    @FXML
    public void exit(ActionEvent event){
        Ex = new Exit();
        Ex.exit();
    }
    @FXML
    public void vol(ActionEvent event){
        Vl = new Vol(mediaPlayer,volumeSlider);
        Vl.vol();
    }
    @FXML
    public void replay(ActionEvent event){
        Rp = new Replay(timeSlider,play,mediaPlayer,PP);
        Rp.replay();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
            replay.setGraphic(new ImageView(new Image(new FileInputStream("src/images/replay.png"))));
            stop.setGraphic(new ImageView(new Image(new FileInputStream("src/images/stop.png"))));
            info.setGraphic(new ImageView(new Image(new FileInputStream("src/images/info.png"))));
            fast.setGraphic(new ImageView(new Image(new FileInputStream("src/images/fast.png"))));
            slow.setGraphic(new ImageView(new Image(new FileInputStream("src/images/slow.png"))));
            exit.setGraphic(new ImageView(new Image(new FileInputStream("src/images/exit.png"))));
            vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/mute.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if(filepath!=null) {
            timeSlider.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(timeSlider.getValue()));
                }
            });
            volumeSlider.valueProperty().addListener(new ChangeListener<Number>() {
                @Override
                public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                    mediaPlayer.setVolume(volumeSlider.getValue());
                }
            });
            // This method of updating time slider dynamically using listener terribly failed
            timeSlider.valueProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    if (timeSlider.isValueChanging())
                        mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(timeSlider.getValue()));
                }
            });
        }
    }
}