package sample;

public class Exit {
    public void exit(){
        System.exit(0);
    }
}