package sample;

import javafx.scene.media.MediaPlayer;

public class Fast {
    public MediaPlayer mediaPlayer;
    Fast(MediaPlayer mp){
        this.mediaPlayer = mp;
    }
    public void fast(){
        double rate=mediaPlayer.getRate();
        if(rate<3){
            mediaPlayer.setRate(rate+0.1);
        }
    }
}
