package sample;

import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.MediaPlayer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Replay {
    public Slider timeSlider;
    public Button play;
    public MediaPlayer mediaPlayer;
    PlayPause PP;
    Replay(Slider ts,Button p, MediaPlayer mp, PlayPause pp){
        this.timeSlider=ts;
        this.play=p;
        this.mediaPlayer=mp;
        this.PP=pp;
    }
    public void replay(){
        mediaPlayer.seek(mediaPlayer.getStartTime());
        PP.play();
        timeSlider.setValue(0);
        mediaPlayer.play();
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/pause.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
