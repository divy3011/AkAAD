package sample;

import javafx.scene.media.MediaPlayer;

public class Slow {
    public MediaPlayer mediaPlayer;
    Slow(MediaPlayer mp){
        this.mediaPlayer = mp;
    }
    public void slow(){
        double rate=mediaPlayer.getRate();
        if(rate>0.1){
            mediaPlayer.setRate(rate-0.1);
        }
    }
}
