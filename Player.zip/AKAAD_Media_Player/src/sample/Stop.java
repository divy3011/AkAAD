package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.MediaPlayer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Stop {
    public Button stop;
    public Button play;
    public MediaPlayer mediaPlayer;
    Stop(Button s,Button p,MediaPlayer mp){
        this.stop=s;
        this.play=p;
        this.mediaPlayer=mp;
    }
    @FXML
    public void stop(){
        mediaPlayer.stop();
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
