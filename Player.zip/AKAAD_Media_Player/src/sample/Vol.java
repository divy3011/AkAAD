package sample;

import javafx.scene.control.Slider;
import javafx.scene.media.MediaPlayer;

public class Vol {
    public MediaPlayer mediaPlayer;
    public Slider volumeSlider;
    Vol(MediaPlayer mp,Slider vS){
        this.mediaPlayer = mp;
        this.volumeSlider = vS;
    }
    public void vol(){
        if(mediaPlayer.getVolume()==0){
            volumeSlider.setValue(100);
        }
        else {
            volumeSlider.setValue(mediaPlayer.getVolume()*0);
        }
    }
}
