package sample;

import com.sun.media.jfxmedia.control.VideoFormat;
import com.sun.media.jfxmedia.events.VideoFrameRateListener;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.naming.Binding;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.floor;
import static java.lang.String.format;

public class Controller implements Initializable {
    @FXML
    private Button play;
    @FXML
    private Button replay;
    @FXML
    private Button stop;
    @FXML
    private Button slow;
    @FXML
    private Button fast;
    @FXML
    private Button exit;
    @FXML
    private Button info;
    @FXML
    private Button vol;
    @FXML
    private Slider volumeSlider;
    @FXML
    private Slider timeSlider;
    @FXML
    private Label timeComplete;
    @FXML
    private Label timeTotal;
    @FXML
    private MenuBar menuBar;
    @FXML
    private MediaView mediaView;
    private MediaPlayer mediaPlayer;
    private String filepath;
    boolean repeat=false;
    File file;
    Media m;
    String information;
    @FXML
    public void handleButtonAction(ActionEvent event){
        try {
            FileChooser chooser = new FileChooser();
            file = chooser.showOpenDialog(null);
            m = new Media(file.toURI().toURL().toString());
            if (mediaPlayer != null) {
                mediaPlayer.dispose();
            }
            mediaPlayer = new MediaPlayer(m);
            mediaView.setMediaPlayer(mediaPlayer);
            DoubleProperty width = mediaView.fitWidthProperty();
            DoubleProperty height = mediaView.fitHeightProperty();
            width.bind(Bindings.selectDouble(mediaView.sceneProperty(),"width"));
            height.bind(Bindings.selectDouble(mediaView.sceneProperty(),"height"));
            mediaPlayer.setOnReady(() -> {
                timeSlider.setMin(0);
                timeSlider.setMax(mediaPlayer.getMedia().getDuration().toMinutes());
                timeSlider.setValue(0);
            });
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
            replay.setGraphic(new ImageView(new Image(new FileInputStream("src/images/replay.png"))));
            stop.setGraphic(new ImageView(new Image(new FileInputStream("src/images/stop.png"))));
            mediaPlayer.currentTimeProperty().addListener(new ChangeListener<Duration>() {
                @Override
                public void changed(ObservableValue<? extends Duration> observable, Duration oldValue, Duration newValue) {
                    Duration d = mediaPlayer.getCurrentTime();
                    timeSlider.setValue(d.toMinutes());
                }
            });
            timeSlider.valueProperty().addListener(new ChangeListener<Number>() {
                @Override
                public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                    if (timeSlider.isPressed()) {
                        double val = timeSlider.getValue();
                        mediaPlayer.seek(new Duration(val * 60 * 1000));
                    }
                }
            });
            volumeSlider.setValue(mediaPlayer.getVolume()*100);
            volumeSlider.valueProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    mediaPlayer.setVolume(volumeSlider.getValue()/100);
                    if(volumeSlider.getValue()==0){
                        try {
                            vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/mute.png"))));
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    else{
                        try {
                            vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/volume.png"))));
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }

                }
            });
            mediaPlayer.currentTimeProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    Duration tC = mediaPlayer.getCurrentTime();
                    Duration tT = mediaPlayer.getTotalDuration();
                    String C=formatTime(tC,tC);
                    int index_C=C.indexOf('/');
                    String TC=C.substring(0,index_C);
                    String T=formatTime(tT,tT);
                    int index_T=T.indexOf('/');
                    String TT=T.substring(0,index_T);
                    timeComplete.setText(TC);
                    timeTotal.setText(TT);
                }
            });

            mediaPlayer.play();
            try {
                play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/pause.png"))));
                vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/volume.png"))));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void play() {
        mediaPlayer.play();
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/pause.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void pause()  {
        mediaPlayer.pause();
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void info(ActionEvent event) {
        ObservableMap<String,Object> objectObservableMap=m.getMetadata();
        String hight = Integer.toString(m.getHeight());
        String width = Integer.toString(m.getWidth());
        String absolute_path=file.getAbsolutePath();
        Duration duration = m.getDuration();
        String or=formatTime(duration,duration);
        int index=or.indexOf('/');
        String dura=or.substring(0,index);
        Object obj=(objectObservableMap.get("composer")==null)?"NA":objectObservableMap.get("composer");
        String composer= obj.toString();
        Object obj1=(objectObservableMap.get("year")==null)?"NA":objectObservableMap.get("year");
        String year= obj1.toString();
        Object obj2=(objectObservableMap.get("album")==null)?"NA":objectObservableMap.get("album");
        String album= obj2.toString();
        Object obj3=(objectObservableMap.get("genre")==null)?"NA":objectObservableMap.get("genre");
        String genre= obj3.toString();
        Object obj4=(objectObservableMap.get("artist")==null)?"NA":objectObservableMap.get("artist");
        String artist= obj4.toString();
        Object obj5=(objectObservableMap.get("title")==null)?"NA":objectObservableMap.get("title");
        String title= obj5.toString();
        if(title!="NA"){
            information="Title:\t\t\t"+title+"\n";
        }
        else{
            int flag1=0,flag2=0;
            for(int i=0;i<absolute_path.length();i++) {
                if (absolute_path.charAt(i) == 92) flag1 = i+1;
                if (absolute_path.charAt(i) == 46) flag2 = i;
            }
            information="Title:\t\t\t"+absolute_path.substring(flag1,flag2)+"\n";
        }
        if(absolute_path!=null){
            information+="Absolute Path:\t"+absolute_path+"\n";
        }
        if(dura!=null){
            information+="Duration:\t\t"+dura+"\n";
        }
        if(m.getHeight()!=0){
            information+="Hight:\t\t"+hight+"\n";
        }
        if(m.getWidth()!=0){
            information+="Width:\t\t"+width+"\n";
        }
        if(composer!="NA"){
            information+="Composer:\t"+composer+"\n";
        }
        if(year!="NA"){
            information+="Year:\t\t\t"+year+"\n";
        }
        if(album!="NA"){
            information+="Album:\t\t"+album+"\n";
        }
        if(genre!="NA"){
            information+="Genre:\t\t"+genre+"\n";
        }
        if(artist!="NA"){
            information+="Artist:\t\t"+artist+"\n";
        }
        Label label = new Label();
        label.setText("Media Information");
        Text textArea=new Text();
        textArea.setText(information);
        BorderPane pane=new BorderPane();
        BorderPane pane1=new BorderPane();
        pane1.setCenter(label);
        pane.setTop(pane1);
        textArea.setFont(new Font("Sans-Serif",10));
        pane.setCenter(textArea);
        Stage stage = new Stage();
        Scene scene = new Scene(pane,650,250);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    public void playpause(ActionEvent event){
        MediaPlayer.Status status = mediaPlayer.getStatus();
        if(status==MediaPlayer.Status.PAUSED ||
                status==MediaPlayer.Status.HALTED ||
                status==MediaPlayer.Status.STOPPED){
            play();
        }
        else{
            pause();
        }
    }
    @FXML
    public void stop(ActionEvent event){
        mediaPlayer.stop();
    }
    @FXML
    public void fast(ActionEvent event){
        double rate=mediaPlayer.getRate();
        if(rate<3){
            mediaPlayer.setRate(rate+0.1);
        }
    }
    @FXML
    public void slow(ActionEvent event){
        double rate=mediaPlayer.getRate();
        if(rate>0.1){
            mediaPlayer.setRate(rate-0.1);
        }
    }
    @FXML
    public void exit(ActionEvent event){
        System.exit(0);
    }
    @FXML
    public void vol(ActionEvent event){
        if(mediaPlayer.getVolume()==0){
            volumeSlider.setValue(100);
        }
        else {
            volumeSlider.setValue(mediaPlayer.getVolume()*0);
        }
    }
    @FXML
    public void replay(ActionEvent event){
        mediaPlayer.seek(mediaPlayer.getStartTime());
        play();
        timeSlider.setValue(0);
        mediaPlayer.play();
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/pause.png"))));
            vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/volume.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    private static String formatTime(Duration elapsed, Duration duration) {
        int intElapsed = (int) floor(elapsed.toSeconds());
        int elapsedHours = intElapsed / (60 * 60);
        if (elapsedHours > 0) {
            intElapsed -= elapsedHours * 60 * 60;
        }
        int elapsedMinutes = intElapsed / 60;
        if(elapsedMinutes>0){
            intElapsed-=elapsedMinutes*60;
        }
        int elapsedSeconds = intElapsed;

        if (duration.greaterThan(Duration.ZERO)) {
            int intDuration = (int) floor(duration.toSeconds());
            int durationHours = intDuration / (60 * 60);
            if (durationHours > 0) {
                intDuration -= durationHours * 60 * 60;
            }
            int durationMinutes = intDuration / 60;
            int durationSeconds = intDuration - durationMinutes * 60;
            if (durationHours > 0) {
                return format("%d:%02d:%02d/%d:%02d:%02d",
                        elapsedHours, elapsedMinutes, elapsedSeconds,
                        durationHours, durationMinutes, durationSeconds);
            }
            else {
                return format("%02d:%02d/%02d:%02d",
                        elapsedMinutes, elapsedSeconds, durationMinutes,
                        durationSeconds);
            }
        }
        else {
            if (elapsedHours > 0) {
                return format("%d:%02d:%02d", elapsedHours,
                        elapsedMinutes, elapsedSeconds);
            } else {
                return format("%02d:%02d", elapsedMinutes,
                        elapsedSeconds);
            }
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            play.setGraphic(new ImageView(new Image(new FileInputStream("src/images/play.png"))));
            replay.setGraphic(new ImageView(new Image(new FileInputStream("src/images/replay.png"))));
            stop.setGraphic(new ImageView(new Image(new FileInputStream("src/images/stop.png"))));
            info.setGraphic(new ImageView(new Image(new FileInputStream("src/images/info.png"))));
            fast.setGraphic(new ImageView(new Image(new FileInputStream("src/images/fast.png"))));
            slow.setGraphic(new ImageView(new Image(new FileInputStream("src/images/slow.png"))));
            exit.setGraphic(new ImageView(new Image(new FileInputStream("src/images/exit.png"))));
            vol.setGraphic(new ImageView(new Image(new FileInputStream("src/images/mute.png"))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if(filepath!=null) {
            timeSlider.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(timeSlider.getValue()));
                }
            });
            volumeSlider.valueProperty().addListener(new ChangeListener<Number>() {
                @Override
                public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                    mediaPlayer.setVolume(volumeSlider.getValue());
                }
            });
            // This method of updating time slider dynamically using listener terribly failed
            timeSlider.valueProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(Observable observable) {
                    if (timeSlider.isValueChanging())
                        mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(timeSlider.getValue()));
                }
            });
        }
    }
}
